# JBDC_Push_To_Github.md

## 📦 Purpose

This document outlines how to push the local `bks_dev` repository (hosted on [git.jbdc.ca](https://git.jbdc.ca)) to GitHub on occasion, without affecting your primary Forgejo remote.

---

## 🔧 Initial Setup (One-Time Only)

1. **Clone your project from Forgejo if not already cloned:**

   ```bash
   git clone https://git.jbdc.ca/platform_engineering/bks_dev.git
   cd bks_dev
   ```

2. **Verify the existing `origin` remote:**

   ```bash
   git remote -v
   ```

   Expected output:

   ```
   origin  https://git.jbdc.ca/platform_engineering/bks_dev.git (fetch)
   origin  https://git.jbdc.ca/platform_engineering/bks_dev.git (push)
   ```

3. **Add GitHub as a secondary remote:**

   ```bash
   git remote add github https://github.com/YOUR_USERNAME/bks_dev.git
   ```

   Replace `YOUR_USERNAME` with your GitHub username.

4. **(Optional)** Confirm that GitHub was added:

   ```bash
   git remote -v
   ```

   You should now see both `origin` and `github`.

---

## 🚀 Pushing to GitHub (Occasional Use)

You can push to GitHub any time without affecting Forgejo by targeting the `github` remote:

### 🔹 Push the main branch

```bash
git push github main
```

> If your branch name is `master`, use that instead:
>
> ```bash
> git push github master
> ```

---

### 🔹 Push all branches

```bash
git push github --all
```

---

### 🔹 Push all tags (optional)

```bash
git push github --tags
```

---

## 🧼 Notes

- **Do not remove or change the `origin` remote.** Forgejo remains your primary remote.
- This setup allows you to manually sync with GitHub as needed.
- Ensure that the GitHub repository is created and **empty** (no README or `.gitignore`), or pushes may fail.

---

## ✅ Example Workflow

```bash
cd /path/to/bks_dev
git pull origin main
# Do your work and commit

# Push to Forgejo
git push origin main

# Occasionally push to GitHub
git push github main
```

---
