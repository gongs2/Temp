# [Backstage](https://backstage.io)

Welcome to PolarisII Project [Polaris](http://172.16.31.135/ps-mw/polaris.git)


# Creating a new instance

To create a new instance of polaris

## 1. Install prereqs


```sh
yarn install
./start.sh
```

## updates

To update the app

```sh
# 1. Install Backstage yarn plugin (one-time setup) 
yarn plugin import https://versions.backstage.io/v1/tags/main/yarn-plugin

# 2. Bump all Backstage + your custom plugins
yarn backstage-cli versions:bump 
yarn backstage-cli versions:bump --pattern '@{backstage,internal,polaris}/*'

# 3. Install dependencies
yarn install

# 4. Check what changed
git status
git diff

# 5. Test the changes
yarn build:backend
./start.sh
```
to check current versions
```sh
# Check what version you're on
cat backstage.json

# See what actual versions are resolved
yarn info @backstage/core-plugin-api version
```