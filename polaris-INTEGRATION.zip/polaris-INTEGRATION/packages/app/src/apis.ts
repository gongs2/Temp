import {
  ScmIntegrationsApi,
  scmIntegrationsApiRef,
  ScmAuth,
} from '@backstage/integration-react';
import {
  AnyApiFactory,
  ApiRef,
  BackstageIdentityApi,
  configApiRef,
  createApiFactory,
  createApiRef,
  OpenIdConnectApi,
  oauthRequestApiRef,
  discoveryApiRef,
  ProfileInfoApi,
  SessionApi,
} from '@backstage/core-plugin-api';
import { OAuth2 } from '@backstage/core-app-api';

/**
 * API reference for Keycloak OIDC authentication
 * This creates a combined API that handles authentication, profile info, and session management
 */
export const keycloakAuthApiRef: ApiRef<
  OpenIdConnectApi & ProfileInfoApi & BackstageIdentityApi & SessionApi
> = createApiRef({
  id: 'auth.oidc', // Changed from 'auth.keycloak' to 'auth.oidc'
});

export const apis: AnyApiFactory[] = [
  // Keycloak OIDC Authentication API
  createApiFactory({
    api: keycloakAuthApiRef,
    deps: {
      discoveryApi: discoveryApiRef,
      oauthRequestApi: oauthRequestApiRef,
      configApi: configApiRef,
    },
    factory: ({ discoveryApi, oauthRequestApi, configApi }) =>
      OAuth2.create({
        configApi,
        discoveryApi,
        oauthRequestApi,
        provider: {
          id: 'oidc', // Changed from 'keycloak' to 'oidc'
          title: 'Keycloak',
          icon: () => null, // You can add a custom Keycloak icon here if desired
        },
        environment: configApi.getOptionalString('auth.environment'),
        defaultScopes: ['openid', 'profile', 'email'],
        popupOptions: {
          // Customize the login popup window
          size: {
            fullscreen: false,
          },
          // Alternative: you can specify width and height directly
          // width: 800,
          // height: 1000,
        },
      }),
  }),

  // SCM Integrations (GitHub, GitLab, etc.)
  createApiFactory({
    api: scmIntegrationsApiRef,
    deps: { configApi: configApiRef },
    factory: ({ configApi }) => ScmIntegrationsApi.fromConfig(configApi),
  }),

  // SCM Authentication (for GitHub, GitLab integrations)
  ScmAuth.createDefaultApiFactory(),
];