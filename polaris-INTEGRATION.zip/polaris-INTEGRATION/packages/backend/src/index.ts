import dotenv from 'dotenv';
import dotenvExpand from 'dotenv-expand';
dotenvExpand.expand(dotenv.config());

import { createBackend } from '@backstage/backend-defaults';

async function main() {
  const backend = createBackend();

  // Core plugins
  backend.add(import('@backstage/plugin-app-backend'));
  backend.add(import('@backstage/plugin-proxy-backend'));

  // Scaffolder
  backend.add(import('@backstage/plugin-scaffolder-backend'));
  backend.add(import('@backstage/plugin-scaffolder-backend-module-github'));
  backend.add(import('@backstage/plugin-scaffolder-backend-module-gitlab')); // Add GitLab support
  backend.add(import('@backstage/plugin-scaffolder-backend-module-gitea')); // Add Gitea/Forgejo support

  // TechDocs
  backend.add(import('@backstage/plugin-techdocs-backend'));

  // Auth - Core auth backend
  backend.add(import('@backstage/plugin-auth-backend'));
  
  // Auth - Providers
  backend.add(import('@backstage/plugin-auth-backend-module-guest-provider'));
  backend.add(import('@backstage/plugin-auth-backend-module-github-provider'));
  backend.add(import('@backstage/plugin-auth-backend-module-oidc-provider'));

  // Catalog
  backend.add(import('@backstage/plugin-catalog-backend'));
  backend.add(import('@backstage/plugin-catalog-backend-module-scaffolder-entity-model'));
  backend.add(import('@backstage/plugin-catalog-backend-module-logs'));
  backend.add(import('@backstage/plugin-catalog-backend-module-github')); // GitHub entity provider
  backend.add(import('@backstage/plugin-catalog-backend-module-gitlab')); // Add GitLab entity provider
  backend.add(import('@backstage/plugin-catalog-backend-module-gitea')); // Add Gitea/Forgejo entity provider

  // Permissions
  backend.add(import('@backstage/plugin-permission-backend'));
  backend.add(import('@backstage/plugin-permission-backend-module-allow-all-policy'));

  // Search
  backend.add(import('@backstage/plugin-search-backend'));
  backend.add(import('@backstage/plugin-search-backend-module-pg'));
  backend.add(import('@backstage/plugin-search-backend-module-catalog'));
  backend.add(import('@backstage/plugin-search-backend-module-techdocs'));

  // Kubernetes
  backend.add(import('@backstage/plugin-kubernetes-backend'));

  await backend.start();
}

main().catch(error => {
  console.error('Failed to start Backstage backend:', error);
  process.exit(1);
});