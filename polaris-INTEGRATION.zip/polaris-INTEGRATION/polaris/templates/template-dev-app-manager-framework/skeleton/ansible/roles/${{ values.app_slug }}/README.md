# Role: ${{ values.app_slug }} — Rootless Podman Manager (Quadlet)

Manage a containerized application on a host using **rootless Podman** with **Quadlet** (`systemd --user`).  
This role intentionally focuses on a single, reliable run style (Quadlet) to reduce complexity and avoid regressions.

---

## What this role does
- Renders a Quadlet unit (`<service>.container`) and targets the **`.service`** unit (never `.container`).
- Ensures `systemd --user` daemon picks up changes via handler (`daemon-reload`).
- Enables and starts the **`<service>.service`** unit with user scope.
- Creates a per-app **env file** named after the service: `{{ app_base_dir }}/{{ app_service_name }}.env`.
- Creates rootless-safe directories under `$HOME`, using **`{{ app_service_name }}`** for the base directory (e.g., `~/test/…`).
- Optionally logs into a registry if `HARBOR_USERNAME` / `HARBOR_PASSWORD` are present in environment.
- Optionally ensures a Podman network if `app_podman_network` is set.

> **Note:** If you later want `run` or `compose`, we can add those back without touching Quadlet code.

---

## Requirements
- Ansible **≥ 2.15**
- Rootless **Podman** installed for the deployment user
- (Optional) Collections if you plan to extend with Podman modules:
  - `containers.podman`
  - `community.general`

---

## Defaults Summary (Quadlet-only)
Override in `inventory/group_vars/` or `host_vars/`, or at play/run time.

| Variable | Purpose | Default / Example |
|---|---|---|
| `app_registry` | Registry hostname (blank allowed) | *(unset here)* |
| `app_namespace` | Registry namespace/project | `devops` |
| `app_image` | Image repo/name (without registry) | `{{ app_namespace }}/{{ app_name }}` |
| `app_image_tag` | Image tag | `latest` |
| `app_name` | Project/repo name | *(from template: `${{ values.name }}` / `${{ values.app_name }}`)* |
| `app_service_name` | **Service/container** name base | `{{ app_name }}` |
| `app_home` | Deploy user home | `{{ ansible_env.HOME }}` (fallback to `/home/<user>` ) |
| `app_base_dir` | Project/base directory | `{{ app_home }}/{{ app_service_name }}` |
| `app_data_dir` | Data directory | `{{ app_base_dir }}/data` |
| `app_config_dir` | Config directory | `{{ app_base_dir }}/config` |
| `app_logs_dir` | Logs directory | `{{ app_base_dir }}/logs` |
| `app_env_file` | Path to rendered env file | `{{ app_base_dir }}/{{ app_service_name }}.env` |
| `app_volumes` | Volume bindings (list) | `[]` (e.g. `["{{ app_data_dir }}:/data:Z"]`) |
| `app_ports` | Published ports (list) | `["8880:8880"]` |
| `app_podman_network` | Optional Podman network name | `""` (unset) |
| `app_auto_update` | Quadlet `AutoUpdate` toggle | `false` |
| `app_preserve_data` | Keep data on undeploy | `true` |
| `app_restart_policy` | Quadlet `[Service] Restart=` | `always` |

> **Image settings** (`app_registry`, `app_image`, `app_image_tag`) are **not** set in role defaults; provide them via `inventory`, CI, or Vault.

---

## Tags implemented
- **`deploy`** — Create/update env & unit, enable and start the service, pre-pull image.
- **`update_config`** — Re-render env/unit and restart (via notify/handlers).
- **`update_image`** — Pull the image and restart (via notify/handlers).

> This Quadlet-only role currently does **not** include separate `start/stop/restart/status/logs/undeploy` tasks.  
> You can still check status and logs directly with `systemctl --user` and `journalctl` (see below).

---

## Handlers
- **`systemd user daemon-reload`** — `systemctl --user daemon-reload` (non-fatal, idempotent).
- **`restart service`** — restarts **`{{ app_service_name }}.service`** with user scope.

---

## Usage

### Minimal inventory
```ini
[targets]
host1

[targets:vars]
# app_registry=<your-registry>      ; leave unset to use a local name or Docker Hub
app_namespace=devops
app_name=test
app_service_name={{ app_name }}
app_image={{ app_namespace }}/{{ app_name }}
app_image_tag=latest
```

### Playbook
Use the generated playbook: `ansible/manage_${{ values.app_slug }}.yml`

### Deploy (first time or after changes)
```bash
ansible-playbook ansible/manage_${{ values.app_slug }}.yml -t deploy
```

### Update image
```bash
ansible-playbook ansible/manage_${{ values.app_slug }}.yml -t update_image
```

### Update config (env/unit re-render + restart)
```bash
ansible-playbook ansible/manage_${{ values.app_slug }}.yml -t update_config
```

---

## Check status & logs (manual)
> These are system tools you can run on the target host.

```bash
# user services
systemctl --user status {{ app_service_name }}.service

# journal logs for the unit
journalctl --user -u {{ app_service_name }}.service -e -f
```

---

## Notes & Tweaks
- **Service name drives everything**: base dir, env file, Quadlet unit, and container name all share `{{ app_service_name }}`.
- **Daemon reload before enable/start**: the role flushes handlers after writing the unit so `systemd --user` sees it.
- **Auto update**: set `app_auto_update: true` to emit `AutoUpdate=registry` in the Quadlet unit (Podman 4.9+).

---

## License
MIT (change in `meta/main.yml` if needed)

## Author
Your Name / Your Org
