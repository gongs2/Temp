#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  tools/check.sh [--mode template|runtime]
  tools/check.sh --template
  tools/check.sh --runtime
  tools/check.sh --help

Defaults to: --mode runtime
USAGE
}

MODE="runtime"

# Argument parsing: --mode/-m, or convenience flags --template / --runtime
while [[ $# -gt 0 ]]; do
  case "${1:-}" in
    --mode|-m)
      shift
      if [[ -z "${1:-}" ]]; then
        echo "Missing argument for --mode"; usage; exit 2
      fi
      MODE="$1"
      ;;
    --template) MODE="template" ;;
    --runtime)  MODE="runtime" ;;
    --help|-h)  usage; exit 0 ;;
    *)
      echo "Unknown argument: $1"
      usage
      exit 2
      ;;
  esac
  shift
done

echo "Mode: $MODE"

# grep exclusions: basenames and dirs
EXCLUDES=( --exclude="check.sh" --exclude="*check.sh" --exclude-dir=".git" --exclude-dir="node_modules" --exclude-dir="vendor" )

# Pattern: only match lines that are NOT comments and contain "enable ... .container"
# ^[[:space:]]*[^#]  -> first non-space char isn't '#'
ENABLE_CONTAINER_NONCOMMENT='^[[:space:]]*[^#].*enable[[:space:]].*\.container\b'

# Patterns for Backstage placeholders (robust: allow any whitespace between ${{ and the token)
PLACEHOLDER_PARAMS_RE='\\$\\{\\{[[:space:]]*parameters'
PLACEHOLDER_VALUES_RE='\\$\\{\\{[[:space:]]*values'

case "$MODE" in
  template)
    echo "A) TEMPLATE: Ensure escaped Jinja exists where expected (group_vars)"
    # Escaped Jinja wrappers must appear in group_vars (template-time only)
    grep -R --line-number "{{ '{{' }}" ansible/group_vars || true
    grep -R --line-number "{{ '}}' }}" ansible/group_vars || true

    echo "B) TEMPLATE: Backstage placeholders are expected; limit scan to Ansible runtime files that MUST NOT keep placeholders"
    # It's OK for placeholders to exist widely in the template repo; this output is informational.
    grep -R --line-number -E "$PLACEHOLDER_PARAMS_RE" ansible || true
    grep -R --line-number -E "$PLACEHOLDER_VALUES_RE" ansible || true

    echo "C) TEMPLATE: Ensure no registry.example.com anywhere (excluding this checker)"
    if MATCHES=$(grep -R -n -I "${EXCLUDES[@]}" "registry.example.com" . 2>/dev/null); then
      echo "$MATCHES"
      echo "Found registry.example.com — fix required"; exit 1
    else
      echo "OK: no registry.example.com found"
    fi

    echo "D) TEMPLATE: Ensure enable targets .service (not .container)"
    if MATCHES=$(grep -R -n -I -E "${EXCLUDES[@]}" "${ENABLE_CONTAINER_NONCOMMENT}" ansible/roles 2>/dev/null); then
      echo "$MATCHES"
      echo "Found systemctl enable on *.container — fix required"; exit 1
    else
      echo "OK: no 'enable *.container' commands found"
    fi

    echo "E) TEMPLATE: Ensure base dir and env file derive from app_service_name (group_vars)"
    # Accept either raw-wrapped or direct references; just require app_service_name appears on these lines
    if ! grep -R -n -I -E '^app_base_dir:.*app_service_name' ansible/group_vars >/dev/null 2>&1; then
      echo "Missing app_service_name in app_base_dir definition in group_vars — fix required"; exit 1
    fi
    if ! grep -R -n -I -E '^app_env_file:.*app_service_name.*\.env' ansible/group_vars >/dev/null 2>&1; then
      echo "Missing app_service_name-based *.env in app_env_file definition in group_vars — fix required"; exit 1
    fi

    echo "F) TEMPLATE: Ensure Quadlet-only (no app_run_style or compose/run code in role)"
    if grep -R -n -I -E "${EXCLUDES[@]}" '\bapp_run_style\b' ansible/roles 2>/dev/null; then
      echo "Found app_run_style in role code — fix required"; exit 1
    fi
    if grep -R -n -I -E "${EXCLUDES[@]}" '\bpodman-compose\b' ansible/roles 2>/dev/null; then
      echo "Found podman-compose in role code — fix required"; exit 1
    fi
    ;;

  runtime)
    echo "A) RUNTIME: Escaped Jinja must NOT exist"
    if grep -R "${EXCLUDES[@]}" --line-number "{{ '{{' }}" ansible 2>/dev/null || \
       grep -R "${EXCLUDES[@]}" --line-number "{{ '}}' }}" ansible 2>/dev/null; then
      echo "Found escaped Jinja in runtime repo — fix required"; exit 1
    fi

    echo "B) RUNTIME: Backstage placeholders must NOT remain"
    if grep -R "${EXCLUDES[@]}" --line-number -E "$PLACEHOLDER_PARAMS_RE" . 2>/dev/null || \
       grep -R "${EXCLUDES[@]}" --line-number -E "$PLACEHOLDER_VALUES_RE" . 2>/dev/null; then
      echo "Found Backstage placeholders in runtime repo — fix required"; exit 1
    fi

    echo "C) RUNTIME: Ensure no registry.example.com"
    if MATCHES=$(grep -R -n -I "${EXCLUDES[@]}" "registry.example.com" . 2>/dev/null); then
      echo "$MATCHES"
      echo "Found registry.example.com — fix required"; exit 1
    fi

    echo "D) RUNTIME: Ensure Quadlet unit enable targets .service (not .container)"
    if MATCHES=$(grep -R -n -I -E "${EXCLUDES[@]}" "${ENABLE_CONTAINER_NONCOMMENT}" ansible/roles 2>/dev/null); then
      echo "$MATCHES"
      echo "Found systemctl enable on *.container — fix required"; exit 1
    fi

    echo "E) RUNTIME: Ensure set_fact does not self-reference (heuristic)"
    awk '
      /set_fact:/ { in_sf=1; next }
      /^- name:/ { in_sf=0 }
      in_sf && /:.*_/ { print FILENAME ":" NR ":" $0 }
    ' $(find ansible/roles -type f -name '*.yml' 2>/dev/null) || true

    echo "F) RUNTIME: Ensure base dir and env file are not hardcoded to /app or app.env"
    if grep -R -n -I -E '^app_base_dir:.*\/app[[:space:]]*$' ansible/group_vars 2>/dev/null; then
      echo "Found app_base_dir ending with '/app' — fix required"; exit 1
    fi
    if grep -R -n -I -E '^app_env_file:.*\/app\.env[[:space:]]*$' ansible/group_vars 2>/dev/null; then
      echo "Found app_env_file set to 'app.env' — fix required"; exit 1
    fi

    echo "G) RUNTIME: Ensure Quadlet-only (no app_run_style var and no podman-compose in role code)"
    if grep -R -n -I -E "${EXCLUDES[@]}" '\bapp_run_style\b' ansible 2>/dev/null; then
      echo "Found app_run_style in runtime repo — fix required"; exit 1
    fi
    if grep -R -n -I -E "${EXCLUDES[@]}" '\bpodman-compose\b' ansible/roles 2>/dev/null; then
      echo "Found podman-compose in role code — fix required"; exit 1
    fi
    ;;

  *)
    echo "Unknown mode: $MODE"
    usage
    exit 2
    ;;
esac

echo "Checks complete."
