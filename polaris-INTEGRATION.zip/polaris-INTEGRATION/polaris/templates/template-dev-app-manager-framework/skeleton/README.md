# ${{ values.name }}

${{ values.description }}

This repository was scaffolded from the **Podman Application Development
(GitLab/Forgejo + Harbor + Ansible)** Backstage template.  
It provides a complete workflow for building, publishing, and managing **rootless Podman Quadlet** applications.

---

## What's Included

### 1) Container Build & Push

- **Makefile** driven workflow:
  - `make build` → builds
    `${{ values.registry_host }}/${{ values.registry_project }}/${{ values.image_name }}:<version>`
  - `make push` → pushes `<version>` and `latest` (and `stable` if enabled)
- `.env` support for local development
- Harbor integration out of the box

### 2) Ansible Management (Rootless Podman Quadlet)

- Lifecycle via role + playbook
- Supported tags:
  - `deploy`
  - `update_image`
  - `update_config`

> Other tags (`start/stop/restart/status/logs/undeploy`) have been removed to keep the role **Quadlet-only** and minimal.  
> You can still check status with `systemctl --user` and logs with `journalctl` directly on the host.

### 3) CI/CD (GitLab or Forgejo)

- Pipelines to build/push images on:
  - New tags
  - Changes to `Containerfile` or `Makefile`
- Optional jobs to run Ansible lifecycle tags from CI/CD

### 4) Defaults

- Base container: Apache httpd
- **Internal port:** `8880`
- **Host port:** `8880` (customizable)

---

## Quick Start

### 1) Configure Variables

The `Makefile` auto-loads `.env` if present. Create one in the repo root:

```dotenv
REGISTRY=${{ values.registry_host }}
HARBOR_PROJECT=${{ values.registry_project }}
IMAGE_NAME=${{ values.image_name }}
UPSTREAM_TAG=latest
HARBOR_USERNAME=your-harbor-user
HARBOR_PASSWORD=your-harbor-password
```

Verify:

```bash
make print-env
```

You should see concrete values (not raw placeholders). Alternatively, override inline:

```bash
make build REGISTRY=${{ values.registry_host }} HARBOR_PROJECT=${{ values.registry_project }} IMAGE_NAME=${{ values.image_name }} UPSTREAM_TAG=latest
make push  REGISTRY=${{ values.registry_host }} HARBOR_PROJECT=${{ values.registry_project }} IMAGE_NAME=${{ values.image_name }}
```

---

### 2) Build & Push Locally

```bash
podman login "$REGISTRY" -u "$HARBOR_USERNAME" -p "$HARBOR_PASSWORD"
make build
make push
```

---

### 3) Deploy with Ansible (Rootless Quadlet)

Install dependencies:

```bash
ansible-galaxy collection install -r requirements.yml
```

Run the playbook (adjust inventory/user as needed):

```bash
ansible-playbook ansible/manage_${{ values.app_slug }}.yml   -i inventory/hosts.yml   -u <ansible_user>   -t deploy
```

---

### 4) Manage Lifecycle

```bash
# Update image
ansible-playbook ansible/manage_${{ values.app_slug }}.yml -i inventory/hosts.yml -u <ansible_user> -t update_image

# Update config (re-render env/unit + restart)
ansible-playbook ansible/manage_${{ values.app_slug }}.yml -i inventory/hosts.yml -u <ansible_user> -t update_config
```

Status/logs can be checked directly on the host:

```bash
systemctl --user status <service>.service
journalctl --user -u <service>.service -e -f
```

---

## Harbor Credentials

- **CI/CD:** set protected variables `HARBOR_USERNAME`, `HARBOR_PASSWORD`.
- **Ansible:** optionally set `registry_username`, `registry_password` (Vault recommended).  
  Pre-tasks export them for the role if present.

---

## Binding Privileged Ports (<1024) (Optional)

If you need ports <1024 with rootless Podman:

```bash
sudo setcap cap_net_bind_service=ep /usr/bin/slirp4netns
getcap /usr/bin/slirp4netns
# /usr/bin/slirp4netns = cap_net_bind_service+ep
```

---

## Repository Layout (high level)

```
repo-root/
  ├── catalog-info.yaml
  ├── README.md
  ├── Containerfile
  ├── Makefile
  ├── ansible/
  │   └── manage_${{ values.app_slug }}.yml
  ├── inventory/
  │   └── hosts.yml
  └── roles/
      └── ${{ values.app_slug }}/
          ├── defaults/main.yml
          ├── tasks/*.yml
          ├── handlers/main.yml
          ├── meta/main.yml
          └── README.md
```

---

## Notes

- Designed for **rootless Podman Quadlet** on Ubuntu 24.04+
- Ansible collections required: `containers.podman`
- Extend tasks/handlers as needed for your app
