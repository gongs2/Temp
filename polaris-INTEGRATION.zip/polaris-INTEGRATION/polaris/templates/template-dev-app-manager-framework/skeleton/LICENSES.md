This project may bundle third-party dependencies licensed under their respective terms.
