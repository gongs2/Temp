# ${{ values.name }}

${{ values.description }}

## Overview

This service was created using Backstage and is hosted on **${{ values.provider | title }}**.

- **Language:** ${{ values.language | title }}
- **Lifecycle:** ${{ values.lifecycle | title }}
- **Owner:** ${{ values.owner }}
- **System:** ${{ values.system }}

## Quick Links

- 🏠 [Backstage Catalog](http://backstage.jbdc.ca:3000/catalog/default/component/${{ values.name }})
- 📦 [Repository](${{ values.repoUrl | parseRepoUrl | pick('host') }}/${{ values.repoUrl | parseRepoUrl | pick('owner') }}/${{ values.repoUrl | parseRepoUrl | pick('repo') }})
{%- if values.provider === 'gitlab' %}
- 🐛 [Issues](${{ values.repoUrl | parseRepoUrl | pick('host') }}/${{ values.repoUrl | parseRepoUrl | pick('owner') }}/${{ values.repoUrl | parseRepoUrl | pick('repo') }}/-/issues)
- 🔀 [Merge Requests](${{ values.repoUrl | parseRepoUrl | pick('host') }}/${{ values.repoUrl | parseRepoUrl | pick('owner') }}/${{ values.repoUrl | parseRepoUrl | pick('repo') }}/-/merge_requests)
{%- else %}
- 🐛 [Issues](${{ values.repoUrl | parseRepoUrl | pick('host') }}/${{ values.repoUrl | parseRepoUrl | pick('owner') }}/${{ values.repoUrl | parseRepoUrl | pick('repo') }}/issues)
- 🔀 [Pull Requests](${{ values.repoUrl | parseRepoUrl | pick('host') }}/${{ values.repoUrl | parseRepoUrl | pick('owner') }}/${{ values.repoUrl | parseRepoUrl | pick('repo') }}/pulls)
{%- endif %}

## Getting Started

{%- if values.language === 'nodejs' %}

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation
```bash
npm install
# or
yarn install
```

### Development
```bash
npm run dev
# or  
yarn dev
```

{%- elif values.language === 'python' %}

### Prerequisites
- Python 3.8+
- pip or poetry

### Installation
```bash
pip install -r requirements.txt
# or
poetry install
```

### Development
```bash
python app.py
# or
poetry run python app.py
```

{%- elif values.language === 'java' %}

### Prerequisites
- Java 11+
- Maven or Gradle

### Installation
```bash
mvn install
# or
./gradlew build
```

### Development
```bash
mvn spring-boot:run
# or
./gradlew bootRun
```

{%- elif values.language === 'go' %}

### Prerequisites
- Go 1.19+

### Installation
```bash
go mod download
```

### Development
```bash
go run main.go
```

{%- else %}

### Prerequisites
Add your prerequisites here.

### Installation
Add installation instructions here.

### Development
Add development instructions here.

{%- endif %}

## Architecture

Add architecture documentation here.

## API Documentation

Add API documentation here.

## Deployment

Add deployment instructions here.

## Contributing

1. Create a feature branch
{%- if values.provider === 'gitlab' %}
2. Make your changes
3. Create a merge request
{%- else %}
2. Make your changes  
3. Create a pull request
{%- endif %}
4. Get approval from the team
5. Merge to main

## Support

For support, please contact the **${{ values.owner }}** team or create an issue in this repository.

---

Generated with ❤️ by [Backstage](http://backstage.jbdc.ca:3000)