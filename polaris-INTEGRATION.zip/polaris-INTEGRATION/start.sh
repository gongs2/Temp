#!/bin/bash

# Stop on error
set -e

# Change to repo root (if script is run from elsewhere)
cd "$(dirname "$0")"

# Global variables
BACKSTAGE_PID=""
WATCH_PID=""

# Function to cleanup ports 3000 and 7007
cleanup_ports() {
  echo "🧹 Checking for processes on ports 3000 and 7007..."
  
  # Check both frontend (3000) and backend (7007) ports
  for port in 3000 7007; do
    local pids=$(lsof -t -i:$port 2>/dev/null || true)
    
    if [ -n "$pids" ]; then
      echo "⚠️  Found processes using port $port: $pids"
      for pid in $pids; do
        echo "🛑 Killing process $pid on port $port..."
        kill -9 $pid 2>/dev/null || true
      done
      sleep 1
    else
      echo "✅ Port $port is free"
    fi
  done
}

# Function to load and validate environment
load_and_validate_env() {
  # Load env vars from .env (if it exists)
  if [ -f .env ]; then
    echo "🔧 Loading environment variables from .env"
    export $(grep -v '^#' .env | xargs)
  else
    echo "⚠️  No .env file found, continuing without it"
  fi

  # Print key environment variables for debugging (helpful for Keycloak setup)
  echo "🌍 Environment Configuration:"
  echo "   BACKSTAGE_FRONTEND_BASE_URL=$BACKSTAGE_FRONTEND_BASE_URL"
  echo "   BACKSTAGE_BACKEND_BASE_URL=$BACKSTAGE_BACKEND_BASE_URL"
  echo "   AUTH_ENVIRONMENT=$AUTH_ENVIRONMENT"
  echo "   KEYCLOAK_BASE_URL=$KEYCLOAK_BASE_URL"
  echo "   KEYCLOAK_REALM=$KEYCLOAK_REALM"
  echo "   KEYCLOAK_CLIENT_ID=$KEYCLOAK_CLIENT_ID"
  echo "   SESSION_SECRET=${SESSION_SECRET:+[SET]}"
  echo "   BACKEND_SECRET=${BACKEND_SECRET:+[SET]}"
  echo "   KEYCLOAK_CLIENT_SECRET=${KEYCLOAK_CLIENT_SECRET:+[SET]}"
  # Print key environment variables for debugging (helpful for Keycloak setup)
  echo "🌍 Environment Configuration:"
  echo "   BACKSTAGE_FRONTEND_BASE_URL=$BACKSTAGE_FRONTEND_BASE_URL"
  echo "   BACKSTAGE_BACKEND_BASE_URL=$BACKSTAGE_BACKEND_BASE_URL"
  echo "   AUTH_ENVIRONMENT=$AUTH_ENVIRONMENT"
  echo "   KEYCLOAK_BASE_URL=$KEYCLOAK_BASE_URL"
  echo "   KEYCLOAK_REALM=$KEYCLOAK_REALM"
  echo "   KEYCLOAK_CLIENT_ID=$KEYCLOAK_CLIENT_ID"
  echo "   SESSION_SECRET=${SESSION_SECRET:+[SET]}"
  echo "   BACKEND_SECRET=${BACKEND_SECRET:+[SET]}"
  echo "   KEYCLOAK_CLIENT_SECRET=${KEYCLOAK_CLIENT_SECRET:+[SET]}"

  # Critical: Check if Keycloak variables are actually set
  if [ -z "$KEYCLOAK_BASE_URL" ] || [ -z "$KEYCLOAK_REALM" ] || [ -z "$KEYCLOAK_CLIENT_ID" ] || [ -z "$KEYCLOAK_CLIENT_SECRET" ]; then
    echo "❌ ERROR: Required Keycloak environment variables are missing!"
    echo "   Please check your .env file contains:"
    echo "   - KEYCLOAK_BASE_URL"
    echo "   - KEYCLOAK_REALM" 
    echo "   - KEYCLOAK_CLIENT_ID"
    echo "   - KEYCLOAK_CLIENT_SECRET"
    exit 1
  fi
  # Critical: Check if Keycloak variables are actually set
  if [ -z "$KEYCLOAK_BASE_URL" ] || [ -z "$KEYCLOAK_REALM" ] || [ -z "$KEYCLOAK_CLIENT_ID" ] || [ -z "$KEYCLOAK_CLIENT_SECRET" ]; then
    echo "❌ ERROR: Required Keycloak environment variables are missing!"
    echo "   Please check your .env file contains:"
    echo "   - KEYCLOAK_BASE_URL"
    echo "   - KEYCLOAK_REALM" 
    echo "   - KEYCLOAK_CLIENT_ID"
    echo "   - KEYCLOAK_CLIENT_SECRET"
    exit 1
  fi

  if [ -z "$SESSION_SECRET" ] || [ -z "$BACKEND_SECRET" ]; then
    echo "❌ ERROR: Required auth secrets are missing!"
    echo "   Please check your .env file contains:"
    echo "   - SESSION_SECRET"
    echo "   - BACKEND_SECRET"
    exit 1
  fi
  if [ -z "$SESSION_SECRET" ] || [ -z "$BACKEND_SECRET" ]; then
    echo "❌ ERROR: Required auth secrets are missing!"
    echo "   Please check your .env file contains:"
    echo "   - SESSION_SECRET"
    echo "   - BACKEND_SECRET"
    exit 1
  fi

  echo "✅ All required environment variables are set"
}

# Function to build and start Backstage
start_backstage() {
  local should_build=$1
  
  # Clean up any existing processes on ports 3000 and 7007 first
  cleanup_ports
  
  if [ "$should_build" = true ]; then
    echo "🔨 Checking syntax..."
    yarn tsc --noEmit 

    echo "🔨 Building backend..."
    yarn build:backend
  else
    echo "⚡ Skipping build steps (using existing build)"
  fi

  echo "🚀 Starting Backstage app..."
  yarn start &
  BACKSTAGE_PID=$!
  echo "📝 Backstage started with PID: $BACKSTAGE_PID"
  
  # Wait a moment to see if the process starts successfully
  sleep 3
  if ! kill -0 $BACKSTAGE_PID 2>/dev/null; then
    echo "❌ Backstage process died shortly after starting"
    BACKSTAGE_PID=""
    return 1
  fi
}

# Function to stop Backstage gracefully
stop_backstage() {
  if [ -n "$BACKSTAGE_PID" ]; then
    echo "🛑 Stopping Backstage (PID: $BACKSTAGE_PID)..."
    kill $BACKSTAGE_PID 2>/dev/null || true
    
    # Wait up to 10 seconds for graceful shutdown
    local count=0
    while kill -0 $BACKSTAGE_PID 2>/dev/null && [ $count -lt 10 ]; do
      sleep 1
      count=$((count + 1))
    done
    
    # Force kill if still running
    if kill -0 $BACKSTAGE_PID 2>/dev/null; then
      echo "⚠️  Force killing Backstage process..."
      kill -9 $BACKSTAGE_PID 2>/dev/null || true
    fi
    
    BACKSTAGE_PID=""
    echo "✅ Backstage stopped"
  fi
  
  # Also kill any remaining processes on ports 3000 and 7007
  cleanup_ports
}

# Function to restart Backstage
restart_backstage() {
  echo "🔄 Restarting Backstage due to configuration change..."
  stop_backstage
  sleep 2
  load_and_validate_env
  start_backstage $BUILD_ON_RESTART
}

# Function to setup file watching
setup_file_watching() {
  # Check if inotify-tools is available (Linux)
  if command -v inotifywait >/dev/null 2>&1; then
    echo "👀 Setting up file watching with inotifywait..."
    (
      while true; do
        inotifywait -e modify,create,delete .env app-config*.yaml 2>/dev/null && {
          echo "📁 Configuration file changed detected"
          restart_backstage
        }
      done
    ) &
    WATCH_PID=$!
  # Check if fswatch is available (macOS/cross-platform)
  elif command -v fswatch >/dev/null 2>&1; then
    echo "👀 Setting up file watching with fswatch..."
    fswatch -o .env app-config*.yaml 2>/dev/null | while read num; do
      echo "📁 Configuration file changed detected"
      restart_backstage
    done &
    WATCH_PID=$!
  # Fallback to polling
  else
    echo "👀 Setting up file watching with polling (install inotify-tools or fswatch for better performance)..."
    (
      LAST_ENV_MTIME=$(stat -f %m .env 2>/dev/null || stat -c %Y .env 2>/dev/null || echo 0)
      LAST_CONFIG_MTIME=$(stat -f %m app-config.yaml 2>/dev/null || stat -c %Y app-config.yaml 2>/dev/null || echo 0)
      
      while true; do
        sleep 2
        CURRENT_ENV_MTIME=$(stat -f %m .env 2>/dev/null || stat -c %Y .env 2>/dev/null || echo 0)
        CURRENT_CONFIG_MTIME=$(stat -f %m app-config.yaml 2>/dev/null || stat -c %Y app-config.yaml 2>/dev/null || echo 0)
        
        if [ "$CURRENT_ENV_MTIME" -gt "$LAST_ENV_MTIME" ] || [ "$CURRENT_CONFIG_MTIME" -gt "$LAST_CONFIG_MTIME" ]; then
          echo "📁 Configuration file change detected"
          LAST_ENV_MTIME=$CURRENT_ENV_MTIME
          LAST_CONFIG_MTIME=$CURRENT_CONFIG_MTIME
          restart_backstage
        fi
      done
    ) &
    WATCH_PID=$!
  fi
  echo "📝 File watcher started with PID: $WATCH_PID"
}

# Function to cleanup on exit
cleanup() {
  echo "🧹 Cleaning up..."
  if [ -n "$WATCH_PID" ]; then
    kill $WATCH_PID 2>/dev/null || true
  fi
  stop_backstage
  cleanup_ports
  exit 0
}

# Function to show usage
show_usage() {
  echo "Usage: $0 [OPTIONS]"
  echo ""
  echo "Options:"
  echo "  --watch, -w    Enable auto-restart on .env changes (default)"
  echo "  --no-watch     Disable auto-restart (run once)"
  echo "  --build, -b    Force build steps (tsc check + backend build)"
  echo "  --no-build     Skip build steps (use existing build)"
  echo "  --help, -h     Show this help message"
  echo ""
  echo "Examples:"
  echo "  $0                    # Start with auto-restart, build only on first start"
  echo "  $0 --build            # Start with auto-restart and full build"
  echo "  $0 --no-watch --build # Single run with full build"
  echo "  $0 --no-build         # Start fast using existing build"
  echo ""
  echo "Build Behavior:"
  echo "  - By default: builds on first start, skips build on restarts"
  echo "  - With --build: always builds (first start + restarts)"
  echo "  - With --no-build: never builds (fastest startup)"
}

# Parse command line arguments
WATCH_ENABLED=true
BUILD_ON_START=true
BUILD_ON_RESTART=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --watch|-w)
      WATCH_ENABLED=true
      shift
      ;;
    --no-watch)
      WATCH_ENABLED=false
      shift
      ;;
    --build|-b)
      BUILD_ON_START=true
      BUILD_ON_RESTART=true
      shift
      ;;
    --no-build)
      BUILD_ON_START=false
      BUILD_ON_RESTART=false
      shift
      ;;
    --help|-h)
      show_usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      show_usage
      exit 1
      ;;
  esac
done

# Setup signal handlers for graceful shutdown
trap cleanup INT TERM

# Initial load and validation
load_and_validate_env

# Start Backstage
start_backstage $BUILD_ON_START

# Setup file watching if enabled
if [ "$WATCH_ENABLED" = true ]; then
  setup_file_watching
  echo "🎯 Backstage is running with auto-restart enabled"
  echo "   Press Ctrl+C to stop"
  
  # Wait for signals
  while true; do
    sleep 1
  done
else
  echo "🎯 Backstage is running without auto-restart"
  echo "   Press Ctrl+C to stop"
  
  # Wait for Backstage process to finish
  wait $BACKSTAGE_PID
fi