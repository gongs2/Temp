# Backstage → PostgreSQL Setup (August 2025)

This guide converts your Backstage backend from in-memory SQLite to PostgreSQL and covers clean (re)creation of the database and user, configuration, dependency install, verification, and troubleshooting.

> Target: Your existing repo where the backend package is `example-backend`, you start with `./start.sh`, and you use `.env` for secrets.

---

## 0) Prerequisites

- **PostgreSQL 14–17** reachable from the Backstage host  
- Shell access with privileges to create DBs/users  
- Your Backstage app checked out locally  

If Postgres isn’t installed yet (Ubuntu example):

```bash
sudo apt update
sudo apt install -y postgresql
sudo systemctl enable --now postgresql
```

---

## 1) Create a Dedicated DB & User (or Recreate Fresh)

You can either **run interactively in `psql`** or **paste a one-liner heredoc**.

### Option A — Interactive (`psql`)

```bash
# Become postgres superuser and open psql
sudo -u postgres psql
```

Inside `psql`, run:

```sql
-- (Re)create the database safely
REVOKE CONNECT ON DATABASE backstage FROM public;
SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='backstage';

DROP DATABASE IF EXISTS backstage;
CREATE DATABASE backstage;

-- Create a dedicated app user (change the password)
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'backstage_user') THEN
    CREATE USER backstage_user WITH PASSWORD 'backstage_pass';
  END IF;
END$$;

-- Grant and transfer ownership
GRANT ALL PRIVILEGES ON DATABASE backstage TO backstage_user;
ALTER DATABASE backstage OWNER TO backstage_user;
```

Quit: `\q`.

### Option B — One-liner (paste into shell)

```bash
sudo -u postgres psql <<'SQL'
REVOKE CONNECT ON DATABASE backstage FROM public;
SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='backstage';
DROP DATABASE IF EXISTS backstage;
CREATE DATABASE backstage;
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'backstage_user') THEN
    CREATE USER backstage_user WITH PASSWORD 'backstage_pass';
  END IF;
END$$;
GRANT ALL PRIVILEGES ON DATABASE backstage TO backstage_user;
ALTER DATABASE backstage OWNER TO backstage_user;
SQL
```

> **Tip:** Replace `backstage_pass` with a strong password. If you prefer to use the `postgres` superuser for development only, skip the user creation and set `POSTGRES_USER=postgres`.

---

## 2) Configure Backstage to Use Postgres

### 2.1 Add/Update environment variables in `.env`

Append these (or update existing values):

```dotenv
# PostgreSQL connection (adjust host if Postgres is remote)
POSTGRES_HOST=127.0.0.1
POSTGRES_PORT=5432
POSTGRES_USER=backstage_user
POSTGRES_PASSWORD=backstage_pass
POSTGRES_DB=backstage
```

> If you use a managed Postgres that requires TLS, see the SSL block in step 2.2.

### 2.2 Replace the `backend.database` block in `app-config.yaml`

Find your existing `backend:` section and replace just the `database:` part with:

```yaml
backend:
  # ... keep your existing backend keys (auth, baseUrl, cors, etc) ...
  database:
    client: pg
    connection:
      host: ${POSTGRES_HOST}
      port: ${POSTGRES_PORT}
      user: ${POSTGRES_USER}
      password: ${POSTGRES_PASSWORD}
      database: ${POSTGRES_DB}
      # If your provider enforces TLS, uncomment & tune:
      # ssl:
      #   require: true
      #   rejectUnauthorized: false
    # Optional pool tuning:
    # pool:
    #   min: 2
    #   max: 10
```

> If you maintain an `app-config.production.yaml`, mirror the same block there and inject the env vars via your process manager (systemd, Docker, Kubernetes, etc.).

---

## 3) Install the Node driver

From your repo root (adjust path if needed):

```bash
# Your backend package is named example-backend
yarn workspace backend add pg
# (Equivalent)
# yarn --cwd packages/backend add pg
```

---

## 4) Verify Connectivity Before Starting Backstage

Quick check from the Backstage host:

```bash
PGPASSWORD="$POSTGRES_PASSWORD" psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c "select version();"
```

Expected: a row printing the PostgreSQL version.

---

## 5) Start Backstage

Ensure `.env` is loaded by your start script; then:

```bash
./start.sh
# or
yarn start
```

Watch the backend logs. On first run with a fresh DB, Knex migrations should execute automatically and tables should be created.

---

## 6) Optional: Run Postgres in Docker (for local dev)

If you don’t have a local Postgres:

```bash
docker run -d --name pg -p 5432:5432 \
  -e POSTGRES_PASSWORD=backstage_pass \
  -e POSTGRES_DB=backstage \
  -e POSTGRES_USER=backstage_user \
  postgres:17.0-bookworm
```

Your `.env` then matches the same host/port/user/password/db.

---

## 7) Common Troubleshooting

- **`ECONNREFUSED` or timeout:** Verify `POSTGRES_HOST`/`PORT` and that Postgres is listening (`ss -lntp | grep 5432`). On remote DBs, check firewalls/security groups.  
- **`password authentication failed`:** Confirm `.env` values; re-set the user password in Postgres:  
  `sudo -u postgres psql -c "ALTER USER backstage_user WITH PASSWORD 'new_secret';"`  
- **`Knex: Timeout acquiring a connection`:** Increase pool max (e.g., `max: 20`) or reduce backend worker concurrency if you run multiple Node processes.  
- **TLS errors with managed Postgres:** Uncomment the `ssl` block. If you have proper CA certs, prefer `rejectUnauthorized: true` with `ssl: { ca: '...cert contents...' }`.  
- **Migrations not running:** Ensure you are starting the **backend** (not only the frontend). In modular setups, migrations are run by the backend process unless explicitly disabled.

---

## 8) (Re)Create Database Quickly (Cheat Sheet)

- **Interactive (`psql`):**

  ```sql
  REVOKE CONNECT ON DATABASE backstage FROM public;
  SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='backstage';
  DROP DATABASE IF EXISTS backstage;
  CREATE DATABASE backstage;
  CREATE USER backstage_user WITH PASSWORD 'backstage_pass';
  GRANT ALL PRIVILEGES ON DATABASE backstage TO backstage_user;
  ALTER DATABASE backstage OWNER TO backstage_user;
  ```

- **Heredoc (shell paste):**

  ```bash
  sudo -u postgres psql <<'SQL'
  REVOKE CONNECT ON DATABASE backstage FROM public;
  SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='backstage';
  DROP DATABASE IF EXISTS backstage;
  CREATE DATABASE backstage;
  DO $$
  BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'backstage_user') THEN
      CREATE USER backstage_user WITH PASSWORD 'backstage_pass';
    END IF;
  END$$;
  GRANT ALL PRIVILEGES ON DATABASE backstage TO backstage_user;
  ALTER DATABASE backstage OWNER TO backstage_user;
  SQL
  ```

- **Connectivity test:**

  ```bash
  PGPASSWORD="backstage_pass" psql -h 127.0.0.1 -U backstage_user -d backstage -c "select now();"
  ```

---

## 9) Backup / Restore Basics

- **Backup a DB:**

  ```bash
  PGPASSWORD="$POSTGRES_PASSWORD" pg_dump -h "$POSTGRES_HOST" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc -f backstage.dump
  ```

- **Restore to a fresh DB:**

  ```bash
  # Create empty DB first (see Section 1), then:
  PGPASSWORD="$POSTGRES_PASSWORD" pg_restore -h "$POSTGRES_HOST" -U "$POSTGRES_USER" -d "$POSTGRES_DB" -c backstage.dump
  ```

---

## 10) Quick Checklist

- [ ] DB `backstage` exists and is owned by `backstage_user`  
- [ ] `.env` has `POSTGRES_*` values  
- [ ] `app-config.yaml` uses `client: pg` with env-driven connection  
- [ ] `pg` Node driver installed in backend package  
- [ ] Backend starts and runs migrations without errors  

---

### Appendix: Your Current `.env` & `app-config.yaml`

You can **keep everything else** you already have. Only the new `POSTGRES_*` variables and the `backend.database` block need to change.

If you later move to production/containers/k8s, inject the same `POSTGRES_*` variables via your runtime (systemd Environment, Docker `-e`, Kubernetes `envFrom` Secrets, etc.) and keep YAML free of credentials.

---
